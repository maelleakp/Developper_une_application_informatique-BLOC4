﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using NEGOSUD.Common.Core;


namespace NEGOSUD.Common.Models
{
	public class Customer : Entity
	{
		public string Name { get; set; }

		public string LastName { get; set; }

		public string Phone { get; set; }

		public string Email { get; set; }

		public DateTime Birthday { get; set; }

        public Customer()
		{
		}
	}
}

