﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class Status : Entity
	{
		public string Name { get; set; }

		public Status()
		{
		}
	}
}

