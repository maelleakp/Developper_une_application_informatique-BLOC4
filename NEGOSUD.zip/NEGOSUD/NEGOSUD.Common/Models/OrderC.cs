﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class OrderC : Entity
	{
		public string OrderNumber { get; set; }

		public DateTime OrderDate { get; set; }

		public DateTime DeliveryDate { get; set; }

		public int Quantity { get; set; }

		public float Price { get; set; }

        public OrderC()
		{
        }
	}
}

