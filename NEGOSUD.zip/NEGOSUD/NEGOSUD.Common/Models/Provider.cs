﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class Provider : Entity
	{
		public string Name { get; set; }

		public string Phone { get; set; }

		public string Email { get; set; }

		public string Siret { get; set; }

		public string WebSite { get; set; }

		public Provider()
		{
		}
	}
}

