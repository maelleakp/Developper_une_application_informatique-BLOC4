﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
    public class OrderP : Entity
    {
        public string OrderNumber { get; set; }

        public DateTime OrderDate { get; set; }

        public int Quantity { get; set; }

        public float Price { get; set; }

        public OrderP()
        {
        }
    }
}

