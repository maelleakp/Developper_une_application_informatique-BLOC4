﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class Address : Entity
    {
        public string PostalCode { get; set; }

        public string City { get; set; }

        public string Street { get; set; }

        public Address()
		{
		}
	}
}

