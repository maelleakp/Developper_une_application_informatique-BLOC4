﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class Item : Entity
	{
		public string Name { get; set; }

		public string Appellation { get; set; }

		public string Reference { get; set; }

		public float Volume { get; set; }

		public int Quantity { get; set; }

		public int Year { get; set; }

		public float UnitPrice { get; set; }

		public float BoxPrice { get; set; }

		public string Region { get; set; }

        public Item()
		{
        }
	}
}

