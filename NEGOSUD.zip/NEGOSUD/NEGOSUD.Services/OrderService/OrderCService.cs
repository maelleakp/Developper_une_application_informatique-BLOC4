﻿using System;
namespace NEGOSUD.Services.OrderService
{
	public class OrderCService
	{
		public OrderCService()
		{
		}
	}
}

