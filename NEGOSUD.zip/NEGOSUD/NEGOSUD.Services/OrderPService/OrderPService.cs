﻿using System;
namespace NEGOSUD.Services.OrderPService
{
	public class OrderPService
	{
		public OrderPService()
		{
		}
	}
}

