﻿using System;
namespace NEGOSUD.Services.OrderPService
{
	public interface IOrderPService
	{
	}
}

