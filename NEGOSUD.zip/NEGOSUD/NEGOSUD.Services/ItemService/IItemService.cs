﻿using System;
namespace NEGOSUD.Services.ItemService
{
	public interface IItemService
	{
	}
}

