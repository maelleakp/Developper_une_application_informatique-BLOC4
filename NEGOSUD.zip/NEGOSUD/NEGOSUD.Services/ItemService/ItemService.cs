﻿using System;
namespace NEGOSUD.Services.ItemService
{
	public class ItemService
	{
		public ItemService()
		{
		}
	}
}

