﻿using System;
namespace NEGOSUD.Services.WineTypeService
{
	public interface IWineTypeService
	{
	}
}

