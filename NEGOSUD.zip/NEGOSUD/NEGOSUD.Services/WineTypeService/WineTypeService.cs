﻿using System;
namespace NEGOSUD.Services.WineTypeService
{
	public class WineTypeService
	{
		public WineTypeService()
		{
		}
	}
}

