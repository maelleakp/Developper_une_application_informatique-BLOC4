﻿using System;
namespace NEGOSUD.Services.OrderService
{
	public interface IOrderService
	{
	}
}

