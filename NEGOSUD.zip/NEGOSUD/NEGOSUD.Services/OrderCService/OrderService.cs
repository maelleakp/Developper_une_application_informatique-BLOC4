﻿using System;
namespace NEGOSUD.Services.OrderService
{
	public class OrderService
	{
		public OrderService()
		{
		}
	}
}

