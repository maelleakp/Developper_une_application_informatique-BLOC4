﻿using System;
namespace NEGOSUD.Services.ProviderService
{
	public class ProviderService
	{
		public ProviderService()
		{
		}
	}
}

