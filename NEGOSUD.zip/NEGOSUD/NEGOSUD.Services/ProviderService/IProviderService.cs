﻿using System;
namespace NEGOSUD.Services.ProviderService
{
	public interface IProviderService
	{
	}
}

