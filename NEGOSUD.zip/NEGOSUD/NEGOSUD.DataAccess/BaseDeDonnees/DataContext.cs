﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess.EntityConfiguration;

namespace NEGOSUD.DataAccess
{
	public class DataContext : DbContext
	{
        public DbSet<Address> Address { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<OrderC> OrdersC { get; set; }
        public DbSet<OrderP> OrdersCP { get; set; }
        public DbSet<Provider> Providers { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Status> Status { get; set; }
        public DbSet<WineType> WineTypes { get; set; }

        public DataContext()
        {

        }

        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            IConfigurationRoot _configuration = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json")
           .Build();

            if (!options.IsConfigured)
            {
                options.UseSqlServer("Server = 127.0.0.1, 1433; Database = bloc4; user id = sa; password = MyPass@word; TrustServerCertificate = true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new EmployeeEntityConfiguration());

            modelBuilder.ApplyConfiguration(new ItemEntityConfiguration());

            modelBuilder.ApplyConfiguration(new OrderCEntityConfiguration());

            modelBuilder.ApplyConfiguration(new OrderPEntityConfiguration());

            modelBuilder.ApplyConfiguration(new ProviderEntityConfiguration());

            modelBuilder.ApplyConfiguration(new WineTypeEntityConfiguration());


        }
    }
}

