﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class CustomerEntityConfiguration : IEntityTypeConfiguration<Customer>
	{
		public CustomerEntityConfiguration()
		{
		}

        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Customer> customer)
        {
            customer.ToTable("customers");
            customer.HasKey(c => c.Id);
            customer.Property(c => c.Id).ValueGeneratedOnAdd();

            customer.Property<string>("Name").IsRequired();
            customer.Property<string>("Surname").IsRequired();
            customer.Property<string>("Email").IsRequired();
            customer.Property<DateTime>("Birthday").IsRequired();
            customer.HasIndex(c => c.Email).IsUnique();
        }
    }
}

