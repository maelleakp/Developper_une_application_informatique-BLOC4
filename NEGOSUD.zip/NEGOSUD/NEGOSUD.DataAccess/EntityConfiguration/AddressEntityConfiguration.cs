﻿using System;
using System.Net;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class AddressEntityConfiguration : IEntityTypeConfiguration<Address>
	{
		public AddressEntityConfiguration()
		{
		}

        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Address> address)
        {
            address.ToTable("address");
            address.HasKey(a => a.Id);
            address.Property(a => a.Id).ValueGeneratedOnAdd();

            address.Property<string>("PostalCode").IsRequired();
            address.Property<string>("City").IsRequired();
            address.Property<string>("Street").IsRequired();
        }
    }
}

